# deep-thought-task
This is a task given in the second round of the selection process at Deep Thought Company.
<br>
![Screenshot 2024-06-12 000526](https://github.com/aryan-gupta-jiit/deep-thought-task/assets/156954758/119dad10-94e4-4d3a-a734-d39fef0963fa)
<br>
![Screenshot 2024-06-12 000644](https://github.com/aryan-gupta-jiit/deep-thought-task/assets/156954758/7978a7c8-88da-4191-8496-88762c032ef4)
<br>
![Screenshot 2024-06-12 000724](https://github.com/aryan-gupta-jiit/deep-thought-task/assets/156954758/1d2846d4-3ecb-4370-97ef-b17decb5d600)



